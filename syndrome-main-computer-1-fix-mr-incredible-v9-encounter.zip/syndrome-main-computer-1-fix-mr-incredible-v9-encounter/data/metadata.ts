export const SITE_URL = 'https://syndromemaincomputer.app'
